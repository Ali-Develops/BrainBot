package edu.ma.appx;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import edu.ma.appx.adapters.ChatAdapter;
import edu.ma.appx.models.Message;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView chatRecyclerView;
    private EditText messageInput;
    private ImageButton sendButton;
    private ChatAdapter chatAdapter;
    private List<Message> messageList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        chatRecyclerView = findViewById(R.id.chatRecyclerView);
        messageInput = findViewById(R.id.messageInput);
        sendButton = findViewById(R.id.sendButton);

        messageList = new ArrayList<>();
        chatAdapter = new ChatAdapter(messageList);
        chatRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        chatRecyclerView.setAdapter(chatAdapter);

        sendButton.setOnClickListener(v -> {
            String userMessage = messageInput.getText().toString().trim();
            if (userMessage.isEmpty()) {
                Toast.makeText(MainActivity.this, "Please enter a message", Toast.LENGTH_SHORT).show();
                return;
            }

            // Add user message
            messageList.add(new Message(userMessage, true));
            chatAdapter.notifyItemInserted(messageList.size() - 1);
            chatRecyclerView.scrollToPosition(messageList.size() - 1);
            messageInput.setText("");

            // Get response from Cohere
            generateAIResponseWithCohere(userMessage);
        });
    }

    private void generateAIResponseWithCohere(String prompt) {
        new Thread(() -> {
            try {
                URL url = new URL("https://api.cohere.ai/v1/generate");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Authorization", "Bearer " + getString(R.string.cohere_api_key));
                conn.setDoOutput(true);

                // Build the JSON body
                JSONObject jsonParam = new JSONObject();
                jsonParam.put("model", "command-r-plus");
                jsonParam.put("prompt", prompt);
                jsonParam.put("max_tokens", 300);
                jsonParam.put("temperature", 0.7);
                jsonParam.put("k", 0);
                jsonParam.put("stop_sequences", new JSONArray());
                jsonParam.put("return_likelihoods", "NONE");

                // Send request
                try (OutputStream os = conn.getOutputStream()) {
                    byte[] input = jsonParam.toString().getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                int responseCode = conn.getResponseCode();
                InputStream inputStream = (responseCode == 200) ? conn.getInputStream() : conn.getErrorStream();

                BufferedReader reader = new BufferedReader(new InputStreamReader(new BufferedInputStream(inputStream), "utf-8"));
                StringBuilder response = new StringBuilder();
                String line;

                while ((line = reader.readLine()) != null) {
                    response.append(line.trim());
                }

                String jsonResponse = response.toString();

                // Extract response
                String replyText = "AI could not respond.";
                JSONObject responseObject = new JSONObject(jsonResponse);
                JSONArray generations = responseObject.getJSONArray("generations");
                if (generations.length() > 0) {
                    JSONObject first = generations.getJSONObject(0);
                    replyText = first.getString("text").trim();
                }

                String finalReply = replyText;

                runOnUiThread(() -> {
                    messageList.add(new Message(finalReply, false));
                    chatAdapter.notifyItemInserted(messageList.size() - 1);
                    chatRecyclerView.scrollToPosition(messageList.size() - 1);
                });

                conn.disconnect();

            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }).start();
    }
}
